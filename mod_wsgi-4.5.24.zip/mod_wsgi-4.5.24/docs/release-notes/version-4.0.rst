===========
Version 4.0
===========

Due to version 4.0 of mod_wsgi being in development for so long, or not in
development depending on how you want to look at it, and the confusion that
might be caused by releasing what was sitting in the source code repository
after so long, the version 4.0 moniker has been dropped. The next version
after the 3.X series will therefore be version 4.1.0. With the introduction
of version 4.1.0, a switch is also being made to a X.Y.Z version numbering
scheme, in place of the existing X.Y version numbering scheme.

* :doc:`version-4.1.0`
